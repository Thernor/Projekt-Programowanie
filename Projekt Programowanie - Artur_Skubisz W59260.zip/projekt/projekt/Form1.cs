﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace projekt
{
    ///Logowanie do systemu zarządzania gospodarstwem
    public partial class Form1 : Form
    {
        public string login, haslo;
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\ARTUR\DESKTOP\NOWY FOLDER\PROJEKT PROGRAMOWANIE - ARTUR_SKUBISZ W59260\PROJEKT\GOSPODARSTWO.MDF;Integrated Security=True;Connect Timeout=30");
        public Form1()
        {
            InitializeComponent();
        }
        ///Funkcja logowania
        public void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string query = "SELECT * FROM Klient WHERE login = '" + textBox1.Text + "' AND haslo = '" + textBox2.Text + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    ///result = true;
                    if (textBox1.Text == "admin")
                    {
                        admin formPanel_Administratora = new admin();
                        formPanel_Administratora.Show();
                        this.Hide();
                    }
                    else
                    {
                        using (StreamWriter writer = new StreamWriter("C:/Users/Artur/Desktop/Nowy folder/Projekt Programowanie - Artur_Skubisz W59260/projekt/projekt/Plik.txt"))
                        {
                            writer.WriteLine(textBox1.Text);
                            writer.WriteLine(textBox2.Text);
                        }
                        Klient formPanel_GlownyUzytkownika = new Klient();
                        formPanel_GlownyUzytkownika.Show();
                        this.Hide();
                    }


                }
                ///Błędne dane logowania
                else
                {
                    MessageBox.Show("Niepoprawny login lub hasło, spróbuj ponownie");
                }
                reader.Close();

            }
            finally
            {
                con.Close();
            }
        }      
    }      
}
