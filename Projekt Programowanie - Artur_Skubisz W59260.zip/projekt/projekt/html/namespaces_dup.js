var namespaces_dup =
[
    [ "projekt", "namespaceprojekt.html", "namespaceprojekt" ]
];