var files_dup =
[
    [ "admin.cs", "admin_8cs.html", [
      [ "admin", "classprojekt_1_1admin.html", "classprojekt_1_1admin" ]
    ] ],
    [ "admin.Designer.cs", "admin_8_designer_8cs.html", [
      [ "admin", "classprojekt_1_1admin.html", "classprojekt_1_1admin" ]
    ] ],
    [ "Form1.cs", "_form1_8cs.html", [
      [ "Form1", "classprojekt_1_1_form1.html", "classprojekt_1_1_form1" ]
    ] ],
    [ "Form1.Designer.cs", "_form1_8_designer_8cs.html", [
      [ "Form1", "classprojekt_1_1_form1.html", "classprojekt_1_1_form1" ]
    ] ],
    [ "Klient.cs", "_klient_8cs.html", [
      [ "Klient", "classprojekt_1_1_klient.html", "classprojekt_1_1_klient" ]
    ] ],
    [ "Klient.Designer.cs", "_klient_8_designer_8cs.html", [
      [ "Klient", "classprojekt_1_1_klient.html", "classprojekt_1_1_klient" ]
    ] ],
    [ "Program.cs", "_program_8cs.html", null ]
];