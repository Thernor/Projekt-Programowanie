var classprojekt_1_1_klient =
[
    [ "Klient", "classprojekt_1_1_klient.html#a558704e1fd8e9d99386d74cf1f4d6215", null ],
    [ "Dispose", "classprojekt_1_1_klient.html#a849c3c7f8d08104f0cdb46bee9fe6389", null ],
    [ "Dostepne_Click", "classprojekt_1_1_klient.html#ade980ced3402933f7cf85079cba696a0", null ],
    [ "InitializeComponent", "classprojekt_1_1_klient.html#a6405d5db675d5338663195a4d12b4c9f", null ],
    [ "Twoje_Click", "classprojekt_1_1_klient.html#a6b599f034a35714649748a48a87c32db", null ],
    [ "uzytkownik_Load", "classprojekt_1_1_klient.html#ae2773de2bb4094a6c95f36fbb0cefb13", null ],
    [ "Wyjdz_Click", "classprojekt_1_1_klient.html#a11486ec8d5965b3a471973c2cd5d3bd6", null ],
    [ "components", "classprojekt_1_1_klient.html#a02595f1c09713bb71dcb2fbbfc7ffa4b", null ],
    [ "con", "classprojekt_1_1_klient.html#a8a9c08020007c88b2e63b7948d0b104d", null ],
    [ "dataGridView1", "classprojekt_1_1_klient.html#a3561ef70d553eb36fa7a6116f6db17af", null ],
    [ "Dostepne", "classprojekt_1_1_klient.html#a984d0f9aeb2214d5d5382abed12aeb0f", null ],
    [ "label1", "classprojekt_1_1_klient.html#a602a030570b50ae85e1a08ed26f81eb3", null ],
    [ "label2", "classprojekt_1_1_klient.html#a51c4fc916c0afa288d242bfd513b3bd5", null ],
    [ "Twoje", "classprojekt_1_1_klient.html#a68548d2aa37c480ef617c9d786f21b84", null ],
    [ "Wyjdz", "classprojekt_1_1_klient.html#ac071303f64fee36cfd60c3b67785f26f", null ]
];