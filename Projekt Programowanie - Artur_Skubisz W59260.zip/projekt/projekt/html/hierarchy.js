var hierarchy =
[
    [ "Form", null, [
      [ "Form1", "classprojekt_1_1_form1.html", null ],
      [ "Klient", "classprojekt_1_1_klient.html", null ],
      [ "admin", "classprojekt_1_1admin.html", null ]
    ] ]
];