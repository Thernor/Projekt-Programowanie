var annotated_dup =
[
    [ "projekt", "namespaceprojekt.html", [
      [ "admin", "classprojekt_1_1admin.html", "classprojekt_1_1admin" ],
      [ "Form1", "classprojekt_1_1_form1.html", "classprojekt_1_1_form1" ],
      [ "Klient", "classprojekt_1_1_klient.html", "classprojekt_1_1_klient" ]
    ] ]
];