﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace projekt
{
    ///Panel administracyjny
    public partial class admin : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\ARTUR\DESKTOP\NOWY FOLDER\PROJEKT PROGRAMOWANIE - ARTUR_SKUBISZ W59260\PROJEKT\GOSPODARSTWO.MDF;Integrated Security=True;Connect Timeout=30");

        public admin()
        {
            InitializeComponent();
        }
        ///Funkcja dodawania klientów
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Klient values('" + textBox1.Text + "', '" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','"+textBox9.Text+"','"+textBox10.Text+"')";
            cmd.ExecuteNonQuery();
            con.Close();           
            MessageBox.Show("Udało się! Dodałeś nowego Klienta!", "Sukces!");
            disp_data_klienci();

            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";

        }
        ///Funkcja wyświetlania istniejących klientów
        public void disp_data_klienci()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Klient";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close(); 
        }

        private void admin_Load(object sender, EventArgs e)
        {
            disp_data_klienci();
        }
        ///Funkcja usuwania klientów
        private void usuń_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;

            if (radioButton1.Checked)
            {
                cmd.CommandText = "delete from Klient where idczyt='" + textBox5.Text + "'";
                cmd.ExecuteNonQuery();
            }
            else if (radioButton2.Checked)
            {
                cmd.CommandText = "delete from Klient where login='" + textBox5.Text + "'";
                cmd.ExecuteNonQuery();
            }
            else if (radioButton3.Checked)
            {
                cmd.CommandText = "delete from Klient where imie='" + textBox5.Text + "'";
                cmd.ExecuteNonQuery();
            }
            else if (radioButton4.Checked)
            {
                cmd.CommandText = "delete from Klient where nazwisko='" + textBox5.Text + "'";
                cmd.ExecuteNonQuery();
            }
            else
            {
                MessageBox.Show("Zaznacz kryteria wyszukiwania!", "Błąd!");
            }           
            con.Close();
            disp_data_klienci();
            textBox5.Text = "";
            MessageBox.Show("Wiersz usunięty", "Sukces");
        }
        ///Funkcja aktualizowania stanu produktów
        private void zaktualizuj_Click(object sender, EventArgs e)
        {                      
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            string sdata;
            sdata = data_sprz.Text;
            if (sdata == "")
            {
                cmd.CommandText = "update Produkty set Sprzedaz = '" + ID_sprz.Text + "', DataModyfikacji = NULL WHERE Nazwa='" + nazwa_sprz.Text + "'";
            }
            else
            {
                cmd.CommandText = "update Produkty set Sprzedaz = '" + ID_sprz.Text + "', DataModyfikacji='" + data_sprz.Text+ "' WHERE Nazwa='" + nazwa_sprz.Text + "'";
            }
            cmd.ExecuteNonQuery();
            con.Close();
            disp_data_produkty();
            MessageBox.Show("Udało się! Zaktualizowałeś rekord!", "Sukces!");            
        }
        ///Funkcja wyszukiwania klientów
        private void szukaj_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            ///Wyszukiwanie klientów po ID
            if (radioButton1.Checked)
            {
                cmd.CommandText = "select * from Klient where idczyt='" + textBox5.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            ///Wyszukiwanie klientów po loginie
            else if (radioButton2.Checked)
            {
                cmd.CommandText = "select * from Klient where login='" + textBox5.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            ///Wyszukiwanie klientów po imieniu
            else if (radioButton3.Checked)
            {
                cmd.CommandText = "select * from Klient where imie='" + textBox5.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            ///Wyszukiwanie klientów po nazwisku
            else if (radioButton4.Checked)
            {
                cmd.CommandText = "select * from Klient where nazwisko='" + textBox5.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            ///Brak zaznaczenia dostępnych opcji
            else
            {
                MessageBox.Show("Zaznacz kryteria wyszukiwania!", "Błąd!");
            }
            
            textBox5.Text = "";
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            disp_data_klienci();
        }
        ///Funkcja wyświetlająca wszystkie produkty
        public void disp_data_produkty()
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Produkty";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
        ///Funkcja dodająca nowe produkty
        private void dodaj_produkt_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Produkty values('" + textBox6.Text + "', '" + textBox7.Text +"', '"+ textBox11.Text +"', '"+"0"+"', '"+ DateTime.Now.ToString("yyyy-MM-dd") + "')"; 
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Operacja powiodła się! Dodałeś nową pozycję do Produkty!");
            disp_data_produkty();

            textBox6.Text = "";
            textBox7.Text = "";
        }

        private void wyswietl_produkty_Click(object sender, EventArgs e)
        {
            disp_data_produkty();
        }
        ///Funkcja wyświetlająca sprzedane produkty
        private void wyswietl_sprzedane_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Produkty where Sprzedaz!='0'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
        ///Funkcja wyświetlająca produkty
        private void szukaj_produkt_Click(object sender, EventArgs e)
        {
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                ///Wyświetla produkty po ID
                if (idProdukt.Checked)
                {
                    cmd.CommandText = "select * from Produkty where idProdukt='" + textBox8.Text + "'";
                    cmd.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                ///Wyświetla produkty po nazwie
                else if (Nazwa.Checked)
                {
                    cmd.CommandText = "select * from Produkty where Nazwa='" + textBox8.Text + "'";
                    cmd.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                ///Wyświetla produkty po ilości
                else if (Ilosc.Checked)
                {
                    cmd.CommandText = "select * from Produkty where Ilosc='" + textBox8.Text + "'";
                    cmd.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                else
                ///Wyświetla błąd przy nie zaznaczeniu żadnej opcji
                {
                    MessageBox.Show("Błąd!", "Zaznacz kryteria wyszukiwania!");                    
                }
                textBox8.Text = "";
                con.Close();
            }
        }
        ///Funkcja kasowania istniejących produktów
        private void usun_produkt_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            ///Funkcja kasowania istniejących produktów po ID
            if (idProdukt.Checked)
            {
                cmd.CommandText = "delete from Produkty where idProdukt='" + textBox8.Text + "'";
                cmd.ExecuteNonQuery();
            }
            ///Funkcja kasowania istniejących produktów po nazwie
            else if (Nazwa.Checked)
            {
                cmd.CommandText = "delete from Produkty where Nazwa='" + textBox8.Text + "'";
                cmd.ExecuteNonQuery();
            }
            ///Funkcja kasowania istniejących produktów po ilosci
            else if (Ilosc.Checked)
            {
                cmd.CommandText = "delete from Produkty where Ilosc='" + textBox8.Text + "'";
                cmd.ExecuteNonQuery();
            }
            ///Nie wybranie zadnej z opcji
            else
            {
                MessageBox.Show("Zaznacz kryteria wyszukiwania!", "Błąd!");
            }
            con.Close();
            disp_data_produkty();
            textBox8.Text = "";
            MessageBox.Show("Produkt usunięty", "Sukces?");
        }
        ///Funkcja wyswietlania dostępnych produktów
        private void wyswietl_dostepne_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Produkty where Sprzedaz='0'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
 
        private void Wyjdz_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Wyjdz_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
