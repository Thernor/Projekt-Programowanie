﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace projekt
{   ///Panel klienta
    public partial class Klient : Form
    {
        
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\ARTUR\DESKTOP\NOWY FOLDER\PROJEKT PROGRAMOWANIE - ARTUR_SKUBISZ W59260\PROJEKT\GOSPODARSTWO.MDF;Integrated Security=True;Connect Timeout=30");
        
        public Klient()
        {
            InitializeComponent();
        }

        private void uzytkownik_Load(object sender, EventArgs e)
        {
            
        }
        ///Funkcja zamknięcia aplikacji
        private void Wyjdz_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        ///Funkcja wyswietlania dostępnych produktów
        private void Dostepne_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Produkty where Sprzedaz='0'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
        ///Funkcja wyswietlania produktów nabytych przez klientów
        private void Twoje_Click(object sender, EventArgs e)
        {         
            string login = File.ReadLines("C:/Users/Artur/Desktop/Nowy folder/Projekt Programowanie - Artur_Skubisz W59260/projekt/projekt/Plik.txt").First();
            string haslo = File.ReadLines("C:/Users/Artur/Desktop/Nowy folder/Projekt Programowanie - Artur_Skubisz W59260/projekt/projekt/Plik.txt").Skip(1).First();
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select idczyt from Klient where login='" + login + "'and haslo='" + haslo +"'";
            int idczyt = (int)cmd.ExecuteScalar();
            con.Close();
            con.Open();
            SqlCommand cmd1 = con.CreateCommand();
            cmd1.CommandType = CommandType.Text;
            cmd1.CommandText = "select * FROM Produkty WHERE Sprzedaz='" + idczyt + "'";
            cmd1.ExecuteNonQuery();
            DataTable dt1 = new DataTable();
            SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
            sda1.Fill(dt1);
            dataGridView1.DataSource = dt1;
            con.Close();
        }
    }           
}

